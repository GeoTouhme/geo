# The Unbroken City — storyboard

70 seconds · 1080×1920 · 30 FPS · 18 scenes · original 112 BPM score

Scene boundaries use detected audio transient frames, not a substituted BPM grid. Typography reveals and line draws use secondary beats. Maps show verified modern physical coastline for orientation; no period political borders. Military diagrams are labeled schematic.

## 01 · 0.00–2.13s · Opening hook

**Fact:** The Umayyad army besieged Constantinople in 717–718.
**Text:** A CAPITAL. / UNDER SIEGE.
**Metadata:** CONSTANTINOPLE · 717–718
**Composition and animation:** Slow emergence of city walls from darkness; title locks on beat 2.
**Timing:** Frames 0–63; local beat frames [0, 16, 32, 48].
**Transition:** emerge from dark navy.
**Source:** https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)#Lead — Lead paragraphs 1–2.

## 02 · 2.13–4.27s · Defence is more than masonry

**Fact:** The Theodosian Walls protected the land approach; naval defence helped prevent a complete blockade.
**Text:** THE WALLS WERE / ONLY HALF / THE DEFENCE.
**Metadata:** LAND AND SEA
**Composition and animation:** Draw the triple defence in perspective; illuminate a narrow sea line.
**Timing:** Frames 64–127; local beat frames [0, 16, 32, 48].
**Transition:** hard cut on detected phrase beat.
**Source:** https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)#Siege — Siege, fleet arrival and provisioning paragraphs.

## 03 · 4.27–8.57s · Establish geography

**Fact:** Constantinople lay on the European shore of the Bosphorus, beside the Sea of Marmara.
**Text:** ONE CITY. / TWO CONTINENTS.
**Metadata:** AT THE BOSPHORUS
**Composition and animation:** Reveal verified physical land polygons and pulse the city marker. No political boundaries.
**Timing:** Frames 128–256; local beat frames [0, 16, 32, 48, 64, 80, 97, 113].
**Transition:** hard cut on detected phrase beat.
**Source:** https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)#Siege — Article coordinates and environs map caption.

## 04 · 8.57–12.83s · Establish the besiegers

**Fact:** Maslama led the Umayyad land campaign into Byzantine Asia Minor in 716.
**Text:** MASLAMA / ADVANCES.
**Metadata:** THE UMAYYAD CAMPAIGN · 716
**Composition and animation:** An abstract column of unit marks advances toward a siege objective; schematic, no claimed route.
**Timing:** Frames 257–384; local beat frames [0, 16, 32, 48, 64, 80, 96, 112].
**Transition:** hard cut on detected phrase beat.
**Source:** https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)#Opening_stages_of_the_campaign — Opening stages, paragraphs on Maslama crossing the Taurus.

## 05 · 12.83–17.13s · Establish the defender

**Fact:** Leo entered Constantinople as emperor on 25 March 717.
**Text:** LEO III / TAKES THE THRONE.
**Metadata:** 25 MARCH 717
**Composition and animation:** Rotate a symbolic coin into view with LEO III lettering. No invented portrait or quotation.
**Timing:** Frames 385–513; local beat frames [0, 16, 32, 49, 65, 81, 97, 113].
**Transition:** hard cut on detected phrase beat.
**Source:** https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)#Opening_stages_of_the_campaign — Opening stages, final paragraph.

## 06 · 17.13–21.40s · Closing the land approach

**Fact:** Maslama crossed the Hellespont into Thrace, then isolated the city on land using double siege lines. The exact opening date is uncertain.
**Text:** THE LAND ROUTE / IS SEALED.
**Metadata:** SUMMER 717
**Composition and animation:** Two red siege lines grow opposite ivory city walls; label the diagram schematic.
**Timing:** Frames 514–641; local beat frames [0, 16, 32, 48, 64, 80, 96, 112].
**Transition:** hard cut on detected phrase beat.
**Source:** https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)#Siege — Siege, first paragraph; footnote a.

## 07 · 21.40–25.70s · The threat at sea

**Fact:** The Arab fleet arrived on 1 September 717 and attempted to blockade the sea approaches.
**Text:** THEN THE / FLEET ARRIVES.
**Metadata:** 1 SEPTEMBER 717
**Composition and animation:** Stagger simplified ships across dark water, progressing on secondary beats.
**Timing:** Frames 642–770; local beat frames [0, 16, 33, 49, 65, 81, 97, 113].
**Transition:** hard cut on detected phrase beat.
**Source:** https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)#Siege — Siege, second paragraph.

## 08 · 25.70–30.00s · First major reversal

**Fact:** A Byzantine squadron used Greek fire against the fleet rearguard near the city.
**Text:** GREEK / FIRE.
**Metadata:** SEPTEMBER 717
**Composition and animation:** A narrow stream of stylized flame crosses the water on the phrase accent; struck ships fade.
**Timing:** Frames 771–899; local beat frames [0, 16, 32, 48, 64, 80, 96, 113].
**Transition:** hard cut on detected phrase beat.
**Source:** https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)#Siege — Siege, fleet rearguard paragraph.

## 09 · 30.00–34.27s · Explain the strategic effect

**Fact:** The incomplete naval blockade allowed provisions to reach Constantinople by sea.
**Text:** THE BLOCKADE / STAYS INCOMPLETE.
**Metadata:** THE CITY CAN STILL RECEIVE FOOD
**Composition and animation:** An ivory supply line crosses a broken red blockade ring into the city. Diagram, not a plotted shipping route.
**Timing:** Frames 900–1027; local beat frames [0, 16, 32, 48, 64, 80, 96, 112].
**Transition:** hard cut on detected phrase beat.
**Source:** https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)#Siege — Siege, provisioning paragraph.

## 10 · 34.27–38.57s · The besiegers become vulnerable

**Fact:** An unusually hard winter afflicted the Arab siege camp.
**Text:** WINTER / TURNS THE SIEGE.
**Metadata:** WINTER 717–718
**Composition and animation:** Snow accumulates across dark tents; motion slows; colder palette.
**Timing:** Frames 1028–1156; local beat frames [0, 16, 32, 48, 64, 80, 97, 113].
**Transition:** hard cut on detected phrase beat.
**Source:** https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)#Siege — Siege, winter paragraph.

## 11 · 38.57–42.83s · Logistical collapse

**Fact:** Famine and disease ravaged the besiegers as supplies ran out. No casualty figure is used.
**Text:** HUNGER. / DISEASE.
**Metadata:** THE BESIEGERS SUFFER
**Composition and animation:** Grain stalks disappear and a supply vessel empties. Qualitative imagery; no numerical chart.
**Timing:** Frames 1157–1284; local beat frames [0, 16, 32, 48, 64, 80, 96, 112].
**Transition:** hard cut on detected phrase beat.
**Source:** https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)#Siege — Siege, winter paragraph.

## 12 · 42.83–47.13s · A possible reprieve

**Fact:** Two fleets carrying supplies and arms arrived from Egypt and Africa in spring 718.
**Text:** RELIEF / SAILS NORTH.
**Metadata:** SPRING 718
**Composition and animation:** Two distinct groups of supply ships approach; labels identify origin without flags.
**Timing:** Frames 1285–1413; local beat frames [0, 16, 32, 49, 65, 81, 97, 113].
**Transition:** hard cut on detected phrase beat.
**Source:** https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)#Siege — Siege, spring reinforcements paragraph.

## 13 · 47.13–51.40s · The reprieve collapses

**Fact:** Christian crew members deserted to the Byzantines; Byzantine attacks destroyed or captured the relief fleets.
**Text:** CREWS DEFECT. / FLEETS ARE LOST.
**Metadata:** SPRING 718
**Composition and animation:** Small crew markers detach; ships disappear beneath sharp crossing diagonals; no casualty imagery.
**Timing:** Frames 1414–1541; local beat frames [0, 16, 32, 48, 64, 80, 96, 112].
**Transition:** hard cut on detected phrase beat.
**Source:** https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)#Siege — Siege, spring reinforcements paragraph.

## 14 · 51.40–55.70s · No rescue from inland

**Fact:** Byzantine troops ambushed the reinforcing Arab army in the hills around Sophon, south of Nicomedia.
**Text:** ON LAND, / RELIEF FAILS.
**Metadata:** NEAR NICOMEDIA · 718
**Composition and animation:** Schematic mountain defile with a halted column; do not claim the precise battlefield geometry.
**Timing:** Frames 1542–1670; local beat frames [0, 16, 33, 49, 65, 81, 97, 113].
**Transition:** hard cut on detected phrase beat.
**Source:** https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)#Siege — Siege, Mardasan paragraph.

## 15 · 55.70–60.00s · Another source of pressure

**Fact:** Bulgar attacks added pressure on the Arab forces. Accounts differ about timing and circumstances.
**Text:** BULGAR / ATTACKS.
**Metadata:** DURING THE SIEGE
**Composition and animation:** A second set of unit symbols presses the siege camp from the rear. Explicit schematic.
**Timing:** Frames 1671–1799; local beat frames [0, 16, 32, 48, 64, 80, 96, 113].
**Transition:** hard cut on detected phrase beat.
**Source:** https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)#Siege — Siege, Bulgar paragraph.

## 16 · 60.00–64.27s · Decisive withdrawal

**Fact:** The Arabs lifted the siege on 15 August 718 following orders to retreat.
**Text:** 15 AUGUST / 718.
**Metadata:** THE SIEGE IS LIFTED
**Composition and animation:** Red siege lines retract; an outlined route resolves away from the city without a geographic claim.
**Timing:** Frames 1800–1927; local beat frames [0, 16, 32, 48, 64, 80, 96, 112].
**Transition:** hard cut on detected phrase beat.
**Source:** https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)#Siege — Siege, withdrawal paragraph.

## 17 · 64.27–66.40s · Resolve the siege

**Fact:** Constantinople remained in Byzantine hands after the failed siege.
**Text:** THE CITY / SURVIVES.
**Metadata:** CONSTANTINOPLE · 718
**Composition and animation:** Return to the opening skyline, now lit by a restrained dawn. Hold instead of constant movement.
**Timing:** Frames 1928–1991; local beat frames [0, 16, 32, 48].
**Transition:** hard cut on detected phrase beat.
**Source:** https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)#Aftermath — Lead outcome and Aftermath.

## 18 · 66.40–70.00s · Avoid a false end-of-war conclusion

**Fact:** Arab raids resumed in 720. The failure of the siege did not end Arab–Byzantine warfare.
**Text:** THE WAR / CONTINUES.
**Metadata:** ARAB RAIDS RESUME · 720
**Composition and animation:** A quiet horizon and timeline from 718 to 720. Final wording stays through the score resolution.
**Timing:** Frames 1992–2099; local beat frames [0, 16, 33, 49].
**Transition:** hard cut on detected phrase beat.
**Source:** https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)#Aftermath — Aftermath, final paragraph.
