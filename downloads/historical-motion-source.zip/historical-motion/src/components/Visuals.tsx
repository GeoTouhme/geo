import React from 'react';
import {interpolate} from 'remotion';
import map from '../data/map.json';

export const C={navy:'#080F18',sea:'#101C2B',land:'#283B4D',ivory:'#F1EFE8',red:'#D7193F',green:'#43A66B',gray:'#A3ACB6',gold:'#C7AC76',ice:'#AFC8DB'};
export const ease=(f:number,a:number,b:number)=>interpolate(f,[a,b],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:t=>1-(1-t)**3});
const label:React.CSSProperties={fontFamily:'Noto Sans',fontSize:22,letterSpacing:3,fill:C.gray};
const Line:React.FC<{d:string;p?:number;color?:string;width?:number;dash?:boolean}>=({d,p=1,color=C.ivory,width=3,dash=false})=><path d={d} fill="none" stroke={color} strokeWidth={width} pathLength={1} strokeDasharray={dash?'.012 .012':1} strokeDashoffset={1-p}/>;
const Cross:React.FC<{x:number;y:number;color?:string}>=({x,y,color=C.ivory})=><path d={`M${x-9},${y}H${x+9}M${x},${y-16}V${y+10}`} stroke={color} strokeWidth={3}/>;

export const Ship:React.FC<{x:number;y:number;s?:number;color?:string;opacity?:number;flip?:boolean;cargo?:boolean}>=({x,y,s=1,color=C.ivory,opacity=1,flip=false,cargo=false})=><g transform={`translate(${x} ${y}) scale(${flip?-s:s} ${s})`} opacity={opacity}>
  <path d="M-65 4 Q-42 38 45 27 L76 -1 L-65 4Z" fill={color}/>
  <path d="M-35 32 Q10 42 66 22" fill="none" stroke={C.gray} opacity=".4"/>
  <path d="M5 -90 V5 M-38 -2 L-25 27 M-18 -1 L-5 29 M3 -1 L16 29 M24 -1 L37 27" stroke={color} strokeWidth="3"/>
  <path d="M10 -87 Q64 -45 15 -8Z" fill={color} opacity=".45"/>
  {cargo&&<g fill={C.gold}><rect x="-39" y="-17" width="17" height="18"/><rect x="-20" y="-17" width="17" height="18"/></g>}
</g>;

const Tower:React.FC<{x:number;y:number;h?:number;w?:number;color?:string}>=({x,y,h=160,w=60,color=C.land})=><g fill={color}>
  <path d={`M${x} ${y}V${y-h}h${w*.2}v-13h${w*.2}v13h${w*.2}v-13h${w*.2}v13h${w*.2}V${y}Z`}/>
  <path d={`M${x+w/2} ${y-h+35}v30`} stroke={C.navy} strokeWidth={9}/>
</g>;

const City:React.FC<{f:number;dawn?:boolean;ending?:boolean}>=({f,dawn=false,ending=false})=>{
 const p=ease(f,0,70); const bright=dawn||ending;
 return <g>
  <defs><radialGradient id="horizon"><stop stopColor={bright?'#C7AC76':'#546D85'} stopOpacity={bright?.35:.12}/><stop offset="1" stopColor={C.navy} stopOpacity="0"/></radialGradient></defs>
  <ellipse cx="560" cy="380" rx="520" ry="320" fill="url(#horizon)" opacity={p}/>
  {!bright&&<circle cx="740" cy="150" r="39" fill={C.ivory} opacity=".65"/>}
  {bright&&<circle cx="580" cy="350" r="110" fill={C.gold} opacity=".12"/>}
  {[...Array(30)].map((_,i)=><circle key={i} cx={(i*167+51)%950} cy={60+(i*71)%300} r={i%3===0?1.6:.9} fill={C.ivory} opacity={bright?.08:.15+.2*Math.sin(i+f/70)**2}/>)}
  <g transform={`translate(0 ${20*(1-p)})`} opacity={p}>
   <path d="M30 560 V480h45v-28h42v40h50v-75h47v65h28v-38h70v60h55v-98h48v-70h18v-30h18v30h18v70h45v90h55v-55h75v-45h34v45h38v70h50v-80h65v90h70v-43h64v87H30Z" fill="#182737"/>
   <path d="M350 475V385H365Q366 295 455 295Q545 295 546 385H562V475Z" fill={C.land}/>
   <path d="M365 385Q455 320 546 385M394 376Q455 250 516 376" stroke={C.gray} strokeWidth="2" opacity=".4" fill="none"/>
   <Cross x={455} y={278} color={C.gold}/>
   <path d="M40 630V530H920V630Z" fill={C.land}/>
   {[...Array(10)].map((_,i)=><Tower key={i} x={40+i*91} y={630} h={125+(i%3)*8} w={52}/>)}
   <path d="M0 642H960" stroke={bright?C.gold:C.gray} opacity=".65"/>
   {[...Array(18)].map((_,i)=><path key={i} d={`M${i*67-60} ${675+(i%3)*18}h${35+i%4*12}`} stroke={C.gray} opacity=".18" strokeWidth={2}/>)}
  </g>
  <text x="480" y="730" textAnchor="middle" style={label}>{ending?'718 → 720':'THE QUEEN OF CITIES'}</text>
 </g>;
};

const Walls:React.FC<{f:number}>=({f})=><g>
 {[0,1,2].map((layer)=><g key={layer} transform={`translate(${layer*35} ${layer*78})`} opacity={.35+layer*.28}>
  <path d="M70 350L770 200V340L70 490Z" fill={C.land} stroke={C.gray} strokeWidth="2"/>
  {[...Array(8)].map((_,i)=><g key={i} transform={`translate(${70+i*100} ${350-i*21.4})`}><Tower x={0} y={0} h={110} w={43}/><path d="M0 -110V0H43" stroke={C.ivory} strokeWidth="2" opacity={ease(f,8+i*3,25+i*3)}/></g>)}
 </g>)}
 <Line d="M95 665L865 500" p={ease(f,20,65)} color={C.gold}/>
 <text x="100" y="720" style={label}>THE THEODOSIAN LAND WALLS</text>
</g>;

const MapVisual:React.FC<{f:number}>=({f})=>{
 const marker=map.markers[0];const p=ease(f,0,38);
 return <g>
  <defs><clipPath id="mapclip"><rect x="15" y="100" width="930" height="550" rx="3"/></clipPath></defs>
  <g clipPath="url(#mapclip)">
   <rect x="15" y="100" width="930" height="550" fill={C.sea}/>
   <g transform="translate(8 110) scale(.99)">
    {map.paths.map((d,i)=><path key={i} d={d} fill={C.land} stroke={C.gray} strokeWidth=".8" fillRule="evenodd" opacity={p}/>)}
    {[...Array(9)].map((_,i)=><path key={i} d={`M${i*120} 0V550 M0 ${i*80}H950`} stroke={C.gray} strokeWidth=".5" opacity=".12"/>)}
    <text x="510" y="180" style={label}>THRACE</text><text x="570" y="450" style={label}>ASIA MINOR</text>
    <text x="420" y="330" style={{...label,fontSize:20,fill:'#8399AD',letterSpacing:5}}>SEA OF MARMARA</text>
    <g transform={`translate(${marker.point[0]} ${marker.point[1]})`} opacity={ease(f,10,30)}>
     <circle r={16+8*Math.sin(f/11)**2} fill="none" stroke={C.gold} opacity=".4"/><circle r="6" fill={C.gold}/>
     <Line d="M0 0L-90 -65H-320" p={ease(f,20,48)} color={C.gold}/>
     <text x="-320" y="-81" style={{...label,fontSize:21,fill:C.ivory}}>CONSTANTINOPLE</text>
    </g>
   </g>
  </g>
  <text x="30" y="710" style={{...label,fontSize:19,letterSpacing:1}}>PHYSICAL COASTLINE · NO POLITICAL BORDERS</text>
  <text x="30" y="742" style={{...label,fontSize:18,letterSpacing:1}}>NATURAL EARTH · MODERN GEOGRAPHIC REFERENCE</text>
 </g>;
};

const Units:React.FC<{x:number;y:number;rows?:number;cols?:number;color?:string;p?:number}>=({x,y,rows=5,cols=6,color=C.red,p=1})=><g>{Array.from({length:rows*cols},(_,i)=><g key={i} opacity={Math.max(0,Math.min(1,p*(rows*cols+3)-i))} transform={`translate(${x+(i%cols)*35} ${y+Math.floor(i/cols)*42})`}><rect width="20" height="25" rx="2" fill={color}/><path d="M4 5L16 20M16 5L4 20" stroke={C.navy} strokeWidth="1.5"/></g>)}</g>;

const Command:React.FC<{f:number}>=({f})=><g>
 <rect x="115" y="140" width="235" height="260" rx="2" fill="none" stroke={C.red} strokeWidth="3"/>
 <path d="M150 175L315 365M315 175L150 365" stroke={C.red} strokeWidth="4"/>
 <text x="115" y="455" style={label}>COMMAND</text>
 <Units x={440} y={160} rows={7} cols={7} p={ease(f,8,80)}/>
 <Line d="M175 630H790L755 606M790 630L755 654" p={ease(f,18,100)} color={C.red}/>
 <text x="115" y="725" style={label}>THE UMAYYAD LAND ARMY</text>
</g>;

const Coin:React.FC<{f:number}>=({f})=>{
 const p=ease(f,0,42);
 return <g transform={`translate(480 385) scale(${.94+.06*p})`} opacity={p}>
  <circle r="240" fill="#292A25" stroke={C.gold} strokeWidth="5"/><circle r="221" fill="none" stroke={C.gold} strokeWidth="1.5"/>
  {Array.from({length:64},(_,i)=>{const a=i*Math.PI/32;return <circle key={i} cx={Math.cos(a)*231} cy={Math.sin(a)*231} r="2" fill={C.gold}/>})}
  <Cross x={0} y={-110} color={C.gold}/><text y="10" textAnchor="middle" fill={C.gold} fontSize="84" fontFamily="Noto Serif Display">LEO III</text>
  <path d="M-90 65H90" stroke={C.gold}/><text y="115" textAnchor="middle" style={{...label,fill:C.gold,fontSize:23}}>BASILEUS</text>
  <text y="320" textAnchor="middle" style={{...label,fontSize:20}}>SYMBOLIC COIN · NOT AN ARTEFACT</text>
 </g>;
};

const Siege:React.FC<{f:number;retreat?:boolean;bulgars?:boolean}>=({f,retreat=false,bulgars=false})=>{
 const p=ease(f,5,65);const ring=retreat?1-p:p;
 return <g>
  <path d="M690 100Q810 140 850 330Q870 540 660 655L590 525V260Z" fill={C.sea}/>
  <path d="M600 180V570L730 515V265Z" fill={C.land} stroke={C.ivory} strokeWidth="3"/>
  {[...Array(6)].map((_,i)=><rect key={i} x="585" y={190+i*65} width="30" height="37" fill={C.ivory}/>)}
  <text x="675" y="380" textAnchor="middle" fill={C.ivory} fontSize="23" fontFamily="Noto Sans" transform="rotate(-90 675 380)">CITY WALLS</text>
  <Line d="M475 120V635" p={ring} color={C.red} width={5}/><Line d="M240 120V635" p={ring} color={C.red} width={5}/>
  <Units x={295} y={230} rows={6} cols={3} p={retreat?1-p:ease(f,25,72)}/>
  {bulgars&&<g opacity={ease(f,6,40)}><Units x={55} y={220} rows={4} cols={3} color={C.gold}/><Line d="M100 490H320L295 470M320 490L295 510" p={p} color={C.gold} width={5}/></g>}
  {retreat&&<Line d="M360 420Q220 450 95 570L130 560M95 570L108 533" p={p} color={C.red} width={5}/>}
  <text x="480" y="715" textAnchor="middle" style={label}>{bulgars?'PRESSURE FROM THE REAR':'LAND APPROACH · SEA APPROACH'}</text>
 </g>;
};

const Fleet:React.FC<{f:number;fire?:boolean;relief?:boolean;defection?:boolean}>=({f,fire=false,relief=false,defection=false})=>{
 const t=ease(f,0,80);
 return <g>
  {[...Array(13)].map((_,i)=><path key={i} d={`M25 ${130+i*43} Q240 ${110+i*43} 480 ${130+i*43} T935 ${130+i*43}`} fill="none" stroke={C.gray} strokeWidth="1" opacity=".10"/>)}
  {[...Array(6)].map((_,i)=>{
    const hit=(fire||defection)&&i<3;const vanish=hit?1-ease(f,25+i*6,65+i*6)*.85:1;
    return <Ship key={i} x={230+(i%3)*260+(1-t)*60} y={275+Math.floor(i/3)*230} color={relief?C.gold:C.red} opacity={ease(f,i*3,20+i*3)*vanish} s={1.1} cargo={relief}/>;
  })}
  {fire&&<g><Ship x={105} y={580} s={.95} color={C.ivory}/>
    <path d="M165 560Q270 370 485 265Q380 420 175 575Z" fill={C.gold} opacity={ease(f,14,22)} transform={`translate(${Math.sin(f*.1)*3} 0)`}/>
    <path d="M172 557Q290 385 480 270Q365 420 180 566Z" fill="#F1EFE8" opacity={ease(f,16,25)*.8}/>
    {[...Array(18)].map((_,i)=><circle key={i} cx={200+i*16} cy={540-i*15+Math.sin(f*.13+i)*9} r={3+(i%3)} fill={i%2?C.gold:C.red} opacity={ease(f,18,30)*.8}/>)}
  </g>}
  {defection&&<g opacity={ease(f,16,45)}><Line d="M250 300Q460 130 700 100" p={ease(f,10,55)} color={C.ivory}/>{[0,1,2,3].map(i=><circle key={i} cx={270+ease(f,10,85)*350+i*13} cy={170+i*12} r="5" fill={C.ivory}/>)}<text x="650" y="65" style={label}>DESERTION</text></g>}
  <text x="480" y="725" textAnchor="middle" style={label}>{relief?'EGYPT + NORTH AFRICA':fire?'GREEK FIRE · STYLIZED RECONSTRUCTION':defection?'DESTROYED OR CAPTURED':'THE SEA APPROACH'}</text>
 </g>;
};

const Supply:React.FC<{f:number}>=({f})=><g>
 <circle cx="480" cy="355" r="205" fill="none" stroke={C.red} strokeWidth="5" strokeDasharray="780 510" transform="rotate(70 480 355)"/>
 <path d="M390 445V280H570V445Z" fill={C.land} stroke={C.ivory} strokeWidth="2"/>
 {[0,1,2].map(i=><rect key={i} x={380+i*80} y="250" width="40" height="65" fill={C.ivory}/>)}
 <Line d="M800 570Q650 580 520 430" p={ease(f,10,60)} color={C.green} width={6}/>
 <Ship x={775-ease(f,10,80)*180} y={575-ease(f,10,80)*120} s={.65} cargo/>
 <text x="480" y="715" textAnchor="middle" style={label}>PROVISIONS STILL REACH THE CITY</text>
</g>;

const Tent:React.FC<{x:number;y:number;s?:number}>=({x,y,s=1})=><g transform={`translate(${x} ${y}) scale(${s})`}><path d="M-85 40L-15 -90L105 40Z" fill={C.land} stroke={C.gray} strokeWidth="1.5"/><path d="M-15 -90L20 40L-85 40Z" fill="#1A2A3B"/><path d="M-30 40L-10 -15L20 40" fill={C.navy}/></g>;
const Winter:React.FC<{f:number}>=({f})=><g>
 <path d="M0 470Q200 420 420 465T960 450V700H0Z" fill="#182533"/><path d="M0 495Q300 460 520 505T960 490" stroke={C.ice} opacity=".5" fill="none"/>
 <Tent x={200} y={390} s={.8}/><Tent x={690} y={370} s={.7}/><Tent x={450} y={490} s={1.5}/>
 {[...Array(70)].map((_,i)=><circle key={i} cx={(i*137+f*(i%3+1)*.3)%960} cy={(i*97+f*(.8+i%4*.15))%660} r={i%4===0?3:1.7} fill={C.ice} opacity={.25+(i%3)*.14}/>)}
 <text x="480" y="725" textAnchor="middle" style={label}>COLD · SCARCITY · EXPOSURE</text>
</g>;

const Grain:React.FC<{f:number}>=({f})=><g>
 {[...Array(7)].map((_,i)=><g key={i} transform={`translate(${210+i*90} 570)`} opacity={1-ease(f,25+i*7,50+i*7)*.88}>
  <path d="M0 0Q-10 -100 0 -265" fill="none" stroke={C.gold} strokeWidth="4"/>
  {[...Array(5)].map((_,j)=><g key={j} transform={`translate(0 ${-80-j*33})`}><ellipse cx="-13" cy="-12" rx="10" ry="24" fill={C.gold} transform="rotate(-35 -13 -12)"/><ellipse cx="13" cy="-12" rx="10" ry="24" fill={C.gold} transform="rotate(35 13 -12)"/></g>)}
 </g>)}
 <path d="M150 600H810" stroke={C.gray} opacity=".4"/>
 <text x="480" y="725" textAnchor="middle" style={label}>A LOGISTICAL DISASTER</text>
</g>;

const Ambush:React.FC<{f:number}>=({f})=><g>
 <path d="M0 360L175 100L340 390L490 180L640 440L810 125L960 400V600H0Z" fill={C.land}/>
 <path d="M0 560L235 325L360 580L550 345L750 600L960 370V670H0Z" fill="#182838"/>
 <Line d="M80 625Q330 460 490 520T850 430" p={ease(f,5,55)} color={C.red} width={5}/>
 <Units x={370} y={460} rows={2} cols={5} p={ease(f,15,40)}/>
 <path d="M435 370L555 490M555 370L435 490" stroke={C.ivory} strokeWidth="8" opacity={ease(f,40,47)}/>
 <text x="480" y="725" textAnchor="middle" style={label}>THE HILLS AROUND SOPHON</text>
</g>;

export const Visual:React.FC<{type:string;f:number}>=({type,f})=>{
 let content:React.ReactNode;
 switch(type){
 case 'city':content=<City f={f}/>;break;
 case 'dawn':content=<City f={f} dawn/>;break;
 case 'ending':content=<City f={f} ending/>;break;
 case 'walls':content=<Walls f={f}/>;break;
 case 'map':content=<MapVisual f={f}/>;break;
 case 'command':content=<Command f={f}/>;break;
 case 'coin':content=<Coin f={f}/>;break;
 case 'siege':content=<Siege f={f}/>;break;
 case 'fleet':content=<Fleet f={f}/>;break;
 case 'fire':content=<Fleet f={f} fire/>;break;
 case 'supply':content=<Supply f={f}/>;break;
 case 'winter':content=<Winter f={f}/>;break;
 case 'grain':content=<Grain f={f}/>;break;
 case 'relief':content=<Fleet f={f} relief/>;break;
 case 'defection':content=<Fleet f={f} defection/>;break;
 case 'ambush':content=<Ambush f={f}/>;break;
 case 'bulgars':content=<Siege f={f} bulgars/>;break;
 case 'retreat':content=<Siege f={f} retreat/>;break;
 default:throw new Error(`Unknown visual: ${type}`);
 }
 return <svg width="960" height="760" viewBox="0 0 960 760" style={{overflow:'visible'}}>{content}</svg>;
};
