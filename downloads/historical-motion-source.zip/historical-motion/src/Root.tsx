import React from 'react';
import {HistoricalDocumentary} from './compositions/HistoricalDocumentary';
import {AbsoluteFill, Composition, interpolate, useCurrentFrame} from 'remotion';

// Technical diagnostic only. Historical content must follow retrieved research.
const RenderCheck: React.FC = () => {
  const frame = useCurrentFrame();
  const progress = interpolate(frame, [0, 59], [0, 1], {extrapolateRight: 'clamp'});
  return <AbsoluteFill style={{backgroundColor: '#080F18', color: '#F1EFE8', alignItems: 'center', justifyContent: 'center', fontFamily: 'sans-serif'}}>
    <svg width="600" height="300" viewBox="0 0 600 300">
      <path d="M40 220 L180 80 L320 220 L460 80 L560 180" fill="none" stroke="#A3ACB6" strokeWidth="3" pathLength="1" strokeDasharray="1" strokeDashoffset={1-progress}/>
      <circle cx={40+520*progress} cy="260" r="9" fill="#D7193F"/>
    </svg>
    <div style={{fontSize: 60, fontWeight: 700}}>RENDER CHECK</div>
    <div style={{fontSize: 27, marginTop: 28, letterSpacing: 3}}>1080 × 1920 / 30 FPS</div>
    <div style={{fontSize: 24, color: '#A3ACB6', marginTop: 50}}>Technical test · not documentary footage</div>
  </AbsoluteFill>;
};

export const Root: React.FC = () => <>
<Composition id="HistoricalDocumentary" component={HistoricalDocumentary} width={1080} height={1920} fps={30} durationInFrames={2100}/>
<Composition id="RenderCheck" component={RenderCheck} width={1080} height={1920} fps={30} durationInFrames={90}/>
</>;
