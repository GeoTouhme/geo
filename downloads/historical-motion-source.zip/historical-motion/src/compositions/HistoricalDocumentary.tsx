import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import timeline from '../data/sceneTimeline.json';
import {C,Visual,ease} from '../components/Visuals';

const decks=[
 'The Umayyad army threatens the Byzantine capital.',
 'Survival depends on the sea as well as stone.',
 'The Bosphorus links the Black Sea and Marmara.',
 'A campaign across Byzantine Asia Minor.',
 'A new emperor faces the coming assault.',
 'Maslama isolates the capital on land.',
 'The besiegers try to cut the sea approaches.',
 'Byzantine ships unleash Greek fire.',
 'Provisions can still arrive by sea.',
 'A harsh winter grips the siege camp.',
 'Famine and epidemics ravage the besiegers.',
 'Two supply fleets offer a possible reprieve.',
 'Desertion and Byzantine attacks defeat the relief.',
 'Byzantine troops ambush the reinforcing army.',
 'Bulgar forces add pressure on the besiegers.',
 'The Arab army abandons the siege.',
 'The capital remains in Byzantine hands.',
 'Victory at the walls does not end the conflict.',
];
const schematic=new Set(['walls','command','siege','supply','ambush','bulgars','retreat']);

type Scene=typeof timeline[number];
const SceneView:React.FC<{scene:Scene;index:number}>=({scene,index})=>{
 const f=useCurrentFrame();
 const lines=scene.headline.split('\n');
 const longest=Math.max(...lines.map(s=>s.length));
 const size=scene.type==='fire'?170:longest>17?78:longest>14?86:longest>12?98:104;
 const ending=scene.type==='ending';
 const beat=(i:number)=>scene.beatSyncFrames[Math.min(i,scene.beatSyncFrames.length-1)]??0;
 const lastAccent=Math.max(...scene.beatSyncFrames.filter(b=>b<=f),0);
 const pulse=Math.exp(-(f-lastAccent)/5);
 return <AbsoluteFill style={{backgroundColor:C.navy,color:C.ivory}}>
   <svg width="1080" height="1920" style={{position:'absolute'}}>
    <defs><radialGradient id="bg"><stop stopColor={index===9?'#1C3041':'#17283B'} stopOpacity=".65"/><stop offset="1" stopColor={C.navy}/></radialGradient></defs>
    <rect width="1080" height="1920" fill="url(#bg)"/>
    {/* Restrained procedural contours: deterministic vector strokes, not a bitmap. */}
    {Array.from({length:9},(_,i)=><path key={i} d={`M${-400+i*100} 1700Q${100+i*75} ${1000-i*28} ${1100+i*40} ${950+i*90}`} fill="none" stroke={C.gray} strokeWidth="1" opacity=".035"/>)}
    <path d="M84 224H996" stroke={C.gray} strokeWidth="1" opacity=".3"/>
    <path d="M84 224H220" stroke={index===7?C.red:C.gold} strokeWidth="3"/>
    <path d="M84 1695H996" stroke={C.gray} strokeWidth="1" opacity=".25"/>
    <circle cx="985" cy="192" r={3+pulse*2} fill={index===7?C.red:C.gold}/>
   </svg>
   <div style={{position:'absolute',left:84,right:84,top:126,display:'flex',justifyContent:'space-between',alignItems:'center',fontFamily:'Noto Sans',fontSize:22,letterSpacing:4,color:C.gray}}>
    <span>THE UNBROKEN CITY</span><span style={{fontSize:20,letterSpacing:2}}>717 — 718</span>
   </div>
   <div style={{position:'absolute',left:84,top:185,fontFamily:'Noto Sans',fontSize:21,letterSpacing:2.3,color:C.gold,opacity:ease(f,0,8)}}>{scene.historicalDate}</div>
   <div data-headline style={{position:'absolute',left:82,right:82,top:282,fontFamily:'Noto Serif Display',fontWeight:700,fontSize:size,lineHeight:1.08,letterSpacing:-2}}>
    {lines.map((line,i)=>{
     const start=beat(i===0?0:Math.min(i,2));const p=ease(f,start,start+7);
     return <div key={i} style={{overflow:'hidden',paddingBottom:8}}><div style={{transform:`translateY(${(1-p)*105}%)`,opacity:p,color:(index===7||index===10)?(i===lines.length-1?C.red:C.ivory):i===lines.length-1&&[3,5,12,14].includes(index)?C.gold:C.ivory}}>{line}</div></div>;
    })}
   </div>
   <div style={{position:'absolute',left:60,top:648,opacity:ease(f,2,16)}}><Visual type={scene.type} f={f}/></div>
   <div style={{position:'absolute',left:84,right:84,top:1454,fontFamily:'Noto Sans',fontSize:21,letterSpacing:3,color:C.gold,opacity:ease(f,beat(1),beat(1)+10)}}>{scene.caption}</div>
   <div data-deck style={{position:'absolute',left:84,right:100,top:1512,fontFamily:'Noto Sans',fontSize:34,lineHeight:1.45,color:C.ivory,opacity:ease(f,beat(2),beat(2)+9)}}>{decks[index]}</div>
   <div style={{position:'absolute',left:84,right:84,top:1730,display:'flex',justifyContent:'space-between',fontFamily:'Noto Sans',fontSize:19,letterSpacing:1.8,color:C.gray}}>
    <span>{schematic.has(scene.type)?'SCHEMATIC · NOT TO SCALE':scene.type==='map'?'GEOGRAPHIC ORIENTATION':ending?'SOURCES & LICENSES IN PROJECT':'AN ANIMATED HISTORY'}</span>
    <span>{String(index+1).padStart(2,'0')} / 18</span>
   </div>
   {ending&&<div style={{position:'absolute',top:1780,left:84,right:84,fontFamily:'Noto Sans',fontSize:18,color:C.gray,lineHeight:1.6,opacity:ease(f,10,25)}}>Adapted from Wikipedia contributors · CC BY-SA 4.0<br/>Original procedural score · CC0 · Made with Natural Earth</div>}
 </AbsoluteFill>;
};

export const HistoricalDocumentary:React.FC=()=>{
 const f=useCurrentFrame();
 const endFade=interpolate(f,[2083,2099],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
 return <AbsoluteFill>
  <style>{`@font-face{font-family:'Noto Serif Display';src:url('${staticFile('assets/fonts/NotoSerifDisplay-Bold.ttf')}') format('truetype');font-weight:700} @font-face{font-family:'Noto Sans';src:url('${staticFile('assets/fonts/NotoSans-Bold.ttf')}') format('truetype');font-weight:400 900} *{box-sizing:border-box}`}</style>
  <Audio src={staticFile('assets/audio/the-unbroken-city.wav')} volume={.9}/>
  {timeline.map((scene,index)=><Sequence key={scene.id} from={scene.startFrame} durationInFrames={scene.durationFrames}><SceneView scene={scene} index={index}/></Sequence>)}
  <div style={{position:'absolute',bottom:0,left:0,width:`${f/2099*100}%`,height:3,backgroundColor:C.gold,opacity:.7}}/>
  <AbsoluteFill style={{backgroundColor:C.navy,opacity:endFade,pointerEvents:'none'}}/>
 </AbsoluteFill>;
};
