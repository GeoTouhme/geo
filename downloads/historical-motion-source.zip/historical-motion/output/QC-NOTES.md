# Final encode inspection

The completed `historical_documentary.mp4` was decoded successfully: 2,100 video
frames, 1080×1920, 30 FPS, 70.000 seconds. Its stereo AAC stream is 70.016 seconds
(including codec padding). Encoded audio correlates with the source at zero
sample lag. Measured final loudness is −18.29 LUFS, with −2.53 dBTP true peak.

A frame was extracted from every scene **from the final MP4**, not just from the
React preview. The complete 18-scene contact sheet was visually inspected.
Full-size title, map, command-symbol, Greek-fire, and ending frames were also
inspected across the rendering checks. No evident clipped headlines, missing
illustrations, accidental overlap, or wrong city-marker placement was found.
The two over-wide draft headlines were reduced before final rendering.

The decorative army banner was replaced with a schematic command symbol; no
unsupported national or period flag is presented. The Greek-fire vessel's bow
orientation was corrected. The final frames show both changes.

Scene boundaries are on measured beat frames; title lines use secondary beat
frames. The Greek-fire sequence begins on a strong phrase accent. The closing
statement stays visible through the musical resolution and fades intentionally
into navy over the final half-second. The original score itself has a fading
tonic ending, rather than an abruptly cut music excerpt.

The physical map uses Natural Earth land polygons. It labels Constantinople at
the supplied article's coordinates and clearly identifies modern physical
coastline as geographic orientation. It does not claim historical territorial
borders, an exact period shoreline, or precise military route geometry.

Claims and dates were checked against the supplied article. Summer 717 avoids
the disputed July/August opening day. Troop and casualty numbers, speculative
counterfactuals, legendary grain stories, and uncertain Bulgar chronology are
omitted. Independent external references could not be retrieved; the source
limitations remain explicit in CREDITS.md and historicalFacts.json.

Checks do not amount to an independent scholarly review or a historical
reconstruction of ships, buildings, equipment, or music. Illustrations are
conceptual and the score is contemporary. This is a text-led documentary with
instrumental music, not a voiced documentary.
