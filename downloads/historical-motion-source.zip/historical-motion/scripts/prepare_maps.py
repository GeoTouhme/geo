"""Clip actual Natural Earth land polygons, never hand-draw the coastline."""
from pathlib import Path
import json
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'.python'))
from shapely.geometry import shape, box

data=json.loads((ROOT/'research/natural-earth.geojson').read_text())
bounds=[25.4,39.6,31.7,42.2]
clip=box(*bounds)
# Equirectangular display corrected at 41 degrees north. Non-political map.
import math
scaleX=150
scaleY=scaleX/math.cos(math.radians(41))
def xy(lon,lat):
    return [(lon-bounds[0])*scaleX,(bounds[3]-lat)*scaleY]
paths=[]
def extract(g):
    if g.is_empty:return
    if g.geom_type=='Polygon':
        rings=[g.exterior,*g.interiors]
        d=[]
        for ring in rings:
            pts=[xy(x,y) for x,y in ring.coords]
            d.append('M'+'L'.join(f'{x:.2f},{y:.2f}' for x,y in pts)+'Z')
        paths.append(''.join(d))
    elif hasattr(g,'geoms'):
        for item in g.geoms:extract(item)
for f in data['features']:
    g=shape(f['geometry'])
    if g.intersects(clip):extract(g.intersection(clip).simplify(.0015,preserve_topology=True))
markers=[{'name':'CONSTANTINOPLE','lon':28.975,'lat':41.0125,'source':'Supplied Wikipedia article coordinates'},
{'name':'NICOMEDIA','lon':29.92,'lat':40.765,'source':'Modern İzmit location; rounded modern geographic reference, not troop position'},
{'name':'ABYDOS','lon':26.406,'lat':40.195,'source':'Approximate archaeological site; not used to infer exact crossing route'}]
for p in markers:p['point']=xy(p['lon'],p['lat'])
result={'paths':paths,'width':(bounds[2]-bounds[0])*scaleX,'height':(bounds[3]-bounds[1])*scaleY,'bounds':bounds,'markers':markers,'source':'Natural Earth 1:10m physical land polygons','sourceUrl':'https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_10m_land.geojson','license':'public domain','note':'Modern physical coastline shown for geographic orientation. No political borders or territorial control; not a reconstruction of the 717 shoreline.'}
(ROOT/'src/data/map.json').write_text(json.dumps(result,separators=(',',':')))
(ROOT/'public/assets/maps/marmara.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {result["width"]} {result["height"]}"><rect width="100%" height="100%" fill="#101c2b"/><g fill="#283b4d" stroke="#a3acb6" stroke-width=".7">'+''.join(f'<path d="{p}" fill-rule="evenodd"/>' for p in paths)+'</g></svg>')
print('Prepared',len(paths),'verified land polygons')
