"""Generate an original deterministic instrumental score; no sampled recordings.

112 BPM, D minor, 4/4, 32 bars plus final resonance. This score is a contemporary
documentary accompaniment, not a reconstruction of eighth-century music.
"""
from pathlib import Path
import json
import numpy as np
from scipy.io import wavfile

ROOT = Path(__file__).resolve().parents[1]
SR = 48000
DURATION = 70
BPM = 112
BEAT = 60 / BPM
rng = np.random.default_rng(717)
mix = np.zeros((SR * DURATION, 2), np.float64)

def add(signal, start, gain=1, pan=0):
    i = int(start * SR)
    n = min(len(signal), len(mix)-i)
    if n <= 0:
        return
    mix[i:i+n, 0] += signal[:n] * gain * np.sqrt((1-pan)/2)
    mix[i:i+n, 1] += signal[:n] * gain * np.sqrt((1+pan)/2)

def note(freq, duration, attack=.02, release=.3):
    t = np.arange(int(SR * duration)) / SR
    e = np.minimum(t/attack, 1) * np.minimum((duration-t)/release, 1)
    s = sum(np.sin(2*np.pi*freq*k*t + .13*k) / k**2 for k in range(1, 6))
    return s*e

chords = [(146.832,174.614,220), (130.813,174.614,220), (130.813,164.814,195.998), (110,138.591,164.814)]
for bar in range(32):
    start = bar*4*BEAT
    chord = chords[(bar//2)%4]
    intensity = .45 if bar < 4 else .7 if bar < 12 else .9 if bar < 24 else .65
    if bar >= 30:
        intensity = .45
    # Sustained harmonics and a high, slow stereo shimmer.
    for j,freq in enumerate(chord):
        add(note(freq, 4*BEAT+.8, .55, .9), start, .040*intensity, (j-1)*.5)
        add(note(freq*2, 4*BEAT+.8, .65, .9), start, .012*intensity, (1-j)*.5)
    for b in range(4):
        at = start+b*BEAT
        # Every beat has a physically rendered low-frequency transient.
        t = np.arange(int(.26*SR))/SR
        kick = np.sin(2*np.pi*(51*t+28*.023*(1-np.exp(-t/.023))))*np.exp(-t*19)
        add(kick, at, .28 if b==0 else .17)
        if bar >= 4 and b in (1,3) and bar < 30:
            t = np.arange(int(.22*SR))/SR
            noise = rng.normal(0,1,len(t))
            noise = noise - np.concatenate(([0],noise[:-1]))*.8
            add(noise*np.exp(-t*27), at, .025*intensity, .15)
        if bar >= 2 and bar < 31:
            for sub in (0,.5):
                t = np.arange(int(.075*SR))/SR
                noise = rng.normal(0,1,len(t))
                high = noise-np.concatenate(([0],noise[:-1]))
                add(high*np.exp(-t*70),at+sub*BEAT,.009*intensity,-.5 if sub==0 else .5)
        if bar >= 4 and bar < 30:
            freq = chord[(b+bar)%3]*2
            t = np.arange(int(.8*SR))/SR
            pluck = (np.sin(2*np.pi*freq*t)+.2*np.sin(2*np.pi*freq*2*t))*np.exp(-t*7)*np.minimum(t/.006,1)
            add(pluck,at,.065*intensity,.45 if b%2 else -.45)
    if bar in (0,2,8,12,16,20,24,28,31):
        t = np.arange(int(1.5*SR))/SR
        impact = rng.normal(0,1,len(t))*np.exp(-t*4)*np.minimum(t/.008,1)
        add(impact,start,.018)

# Final tonic on beat 128 with a 1.43-second natural decay.
for f in (73.416,146.832,174.614,220,293.665):
    add(note(f, 1.42, .015, 1.1),128*BEAT,.045)
# Short stereo room reflections: deterministic, no external samples.
dry = mix.copy()
for delay,gain in ((.071,.16),(.137,.10),(.223,.06)):
    k = int(delay*SR)
    mix[k:] += dry[:-k, ::-1]*gain
fade = np.minimum(np.arange(len(mix))/SR/.012,1)
fade *= np.minimum((len(mix)-1-np.arange(len(mix)))/SR/.65,1)
mix *= fade[:,None]
peak = np.max(np.abs(mix))
mix *= .84/peak
dest = ROOT/'public/assets/audio'
dest.mkdir(parents=True,exist_ok=True)
wavfile.write(dest/'the-unbroken-city.wav', SR, (mix*32767).astype(np.int16))
(dest/'LICENSE.txt').write_text('The Unbroken City — original procedural instrumental score.\nGenerated entirely from oscillators and seeded noise by scripts/compose_score.py.\nNo third-party recordings or musical compositions are incorporated.\nThe generated audio is dedicated to the public domain under CC0 1.0, to the extent any rights apply.\nhttps://creativecommons.org/publicdomain/zero/1.0/\nContemporary documentary score; not a historical music reconstruction.\n')
(ROOT/'research/score-design.json').write_text(json.dumps({'bpm':BPM,'meter':'4/4','durationSeconds':70,'bars':32,'tonality':'D minor','seed':717,'sampleRate':SR,'channels':2,'license':'CC0-1.0','finalTonicSeconds':128*BEAT},indent=2))
print('Generated original stereo score:',dest/'the-unbroken-city.wav')
