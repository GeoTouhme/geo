"""Measure beats and phrase accents from the actual rendered waveform."""
from pathlib import Path
import json
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfiltfilt, find_peaks

ROOT = Path(__file__).resolve().parents[1]
sr, x = wavfile.read(ROOT/'public/assets/audio/the-unbroken-city.wav')
mono = x.astype(np.float64).mean(axis=1)/32768
# The score's low drum is isolated from its pads (all pads > 110 Hz).
low = sosfiltfilt(butter(4,[35,90],btype='bandpass',fs=sr,output='sos'),mono)
hop = 240
energy = np.sqrt(np.mean(low[:len(low)//hop*hop].reshape(-1,hop)**2,axis=1))
peaks, props = find_peaks(energy,distance=int(.38*sr/hop),prominence=.012)
# Find each transient's leading edge, not its later maximum.
onsets=[]
strengths=[]
for p in peaks:
    start=p
    while start>0 and energy[start] > energy[p]*.20 and p-start<20:
        start-=1
    # The final sustained tonic contains slow interference peaks, not drum beats.
    # The composed percussion ends before the final tonic at 68.571 s.
    if start*hop/sr >= 68.3:
        continue
    onsets.append(round(start*hop/sr,5))
    strengths.append(float(energy[p]))
if len(onsets)<100:
    raise RuntimeError(f'Insufficient detected rhythm: {len(onsets)} beats')
intervals=np.diff(onsets)
bpm=60/float(np.median(intervals))
if not 108 < bpm < 116:
    raise RuntimeError(f'Unexpected estimated tempo {bpm}')
beats=[{'index':i,'time':t,'frame':round(t*30),'strength':round(strengths[i],5),'downbeat':i%4==0} for i,t in enumerate(onsets)]
sections=[]
for a,b,label in [(0,8,'The threat'),(8,32,'The approach'),(32,64,'Fire and winter'),(64,96,'Failed relief'),(96,120,'Withdrawal'),(120,len(beats),'Resolution')]:
    part=mono[int(beats[a]['time']*sr):int((beats[b]['time'] if b<len(beats) else 70)*sr)]
    sections.append({'label':label,'startSeconds':beats[a]['time'],'endSeconds':beats[b]['time'] if b<len(beats) else 70,'rms':round(float(np.sqrt(np.mean(part**2))),5)})
result={'method':'35–90 Hz waveform energy; measured transient leading edges at 5 ms resolution; no fixed-BPM grid substituted','estimatedBpm':round(bpm,3),'meter':'4/4','meterProvenance':'Known score structure; downbeats are indexed from detected first transient, not inferred independently','durationSeconds':len(mono)/sr,'sampleRate':sr,'beatCount':len(beats),'beats':beats,'sections':sections,'resolution':{'startSeconds':68.57143,'endSeconds':70,'method':'Score design, verified by waveform tail'},'limitations':'Phrase grouping and 4/4 meter use known original score structure. Beat times and relative strengths are measured.'}
(ROOT/'src/data/audioBeats.json').write_text(json.dumps(result,indent=2))
print('Detected',len(beats),'beats; estimated BPM',round(bpm,3))
