const {bundle}=require('@remotion/bundler');
const {selectComposition,renderStill,openBrowser}=require('@remotion/renderer');
const path=require('path');
const scenes=require('../src/data/sceneTimeline.json');
(async()=>{
 const serveUrl=await bundle({entryPoint:path.resolve('src/index.ts')});
 const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium'});
 try{
  const composition=await selectComposition({serveUrl,id:'HistoricalDocumentary',puppeteerInstance:browser});
  for (let i=0;i<scenes.length;i++){
   const s=scenes[i], frame=s.startFrame+Math.min(s.durationFrames-6,Math.round(s.durationFrames*.73));
   await renderStill({serveUrl,composition,frame,output:`output/frames/${s.id}.png`,puppeteerInstance:browser});
   console.log(`${i+1}/18: ${s.id} frame ${frame}`);
  }
 }finally{await browser.close({silent:true});}
})();
