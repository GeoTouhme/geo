"""Bundle editable source and evidence; the final MP4 is delivered separately."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
ROOT=Path(__file__).resolve().parents[1]
dest=ROOT/'output/historical-motion-source.zip'
files=[]
for directory in ['src','scripts','public','research']:
    files.extend(p for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for name in ['package.json','package-lock.json','tsconfig.json','.npmrc','.gitignore','README.md','STORYBOARD.md','CREDITS.md','LICENSE-CODE.txt','requirements.txt']:
    files.append(ROOT/name)
for name in ['quality-control.json','QC-NOTES.md','storyboard-contact-sheet.jpg']:
    p=ROOT/'output'/name
    if p.exists():files.append(p)
files.extend(sorted((ROOT/'output/frames').glob('*.png')))
with ZipFile(dest,'w',compression=ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(set(files)):
        z.write(p,Path('historical-motion')/p.relative_to(ROOT))
with ZipFile(dest) as z:
    assert z.testzip() is None
print('Packaged',len(files),'files:',dest,'bytes:',dest.stat().st_size)
