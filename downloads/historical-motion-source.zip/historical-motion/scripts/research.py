"""Retrieve the requested source without disabling TLS or fabricating content."""
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError
from html.parser import HTMLParser
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
URL = 'https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)'

class ArticleText(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []
        self.skip = 0
    def handle_starttag(self, tag, attrs):
        if tag in ('script', 'style'):
            self.skip += 1
        if tag in ('p', 'h1', 'h2', 'h3', 'li'):
            self.parts.append('\n')
    def handle_endtag(self, tag):
        if tag in ('script', 'style') and self.skip:
            self.skip -= 1
    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)

def main():
    dest = ROOT / 'research'
    dest.mkdir(exist_ok=True)
    try:
        req = Request(URL, headers={'User-Agent': 'HistoricalMotionResearch/0.1 (source retrieval)'})
        with urlopen(req, timeout=45) as response:
            html = response.read().decode('utf-8')
        parser = ArticleText()
        parser.feed(html)
        text = ''.join(parser.parts)
        if 'Siege of Constantinople' not in text or len(text) < 10000:
            raise ValueError('Response is not the expected full source article')
        (dest / 'wikipedia.html').write_text(html)
        (dest / 'wikipedia.txt').write_text(text)
        print(f'Saved source article ({len(text)} text characters). Fact-check citations before scripting.')
    except (URLError, OSError, ValueError) as exc:
        print(f'Source retrieval blocked: {exc}', file=sys.stderr)
        return 1
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
