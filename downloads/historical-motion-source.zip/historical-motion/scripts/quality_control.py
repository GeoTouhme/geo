"""Validate the real final encode, export scene frames, and record limitations."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from scipy.io import wavfile
import subprocess,json,hashlib,math,re
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output'
VIDEO=OUT/'historical_documentary.mp4'
scenes=json.loads((ROOT/'src/data/sceneTimeline.json').read_text())
audio=json.loads((ROOT/'src/data/audioBeats.json').read_text())
def run(args):
    return subprocess.run(args,capture_output=True,text=True,check=True)
probe=json.loads(run(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(VIDEO)]).stdout)
v=next(x for x in probe['streams'] if x['codec_type']=='video')
a=next(x for x in probe['streams'] if x['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],v['codec_name'])==(1080,1920,'30/1','h264')
assert int(v['nb_read_frames'])==2100
assert abs(float(v['duration'])-70)<.034
assert a['channels']==2 and a['codec_name']=='aac'
assert abs(float(a['duration'])-70)<.05
assert scenes[0]['startFrame']==0
for i,s in enumerate(scenes):
    assert s['durationFrames']>0
    assert s['startFrame']+s['durationFrames']==(scenes[i+1]['startFrame'] if i+1<len(scenes) else 2100)
    assert s['sourceUrls']
measured=[x['frame'] for x in audio['beats']]
assert all(s['startFrame'] in measured for s in scenes)
assert max(abs(b['time']*30-b['frame']) for b in audio['beats'])<=.5
# Actual font metrics, including the production's -2px tracking.
widths=[]
for s in scenes:
    lines=s['headline'].split('\n');n=max(map(len,lines))
    size=170 if s['type']=='fire' else 78 if n>17 else 86 if n>14 else 98 if n>12 else 104
    font=ImageFont.truetype(str(ROOT/'public/assets/fonts/NotoSerifDisplay-Bold.ttf'),size)
    w=max(font.getlength(t)-2*(len(t)-1) for t in lines)
    assert w<=916,(s['id'],w)
    widths.append({'scene':s['id'],'maxLinePixels':round(w,2),'availablePixels':916})
# Decode the entire file, not only container metadata.
decode=run(['ffmpeg','-v','error','-i',str(VIDEO),'-f','null','-'])
assert not decode.stderr.strip(),decode.stderr
frame_dir=OUT/'frames';frame_dir.mkdir(exist_ok=True)
files=[]
selected=[s['startFrame']+min(s['durationFrames']-6,round(s['durationFrames']*.73)) for s in scenes]
expr='+'.join(f'eq(n\\,{f})' for f in selected)
run(['ffmpeg','-v','error','-y','-i',str(VIDEO),'-vf',f'select={expr}','-fps_mode','vfr',str(frame_dir/'encoded-%02d.png')])
for i,(s,frame) in enumerate(zip(scenes,selected),1):
    encoded=frame_dir/f'encoded-{i:02d}.png'
    dest=frame_dir/(s['id']+'.png')
    assert encoded.exists() and encoded.stat().st_size>5000
    encoded.replace(dest)
    files.append((dest,frame))
sheet=Image.new('RGB',(1080,2550),'#080F18');draw=ImageDraw.Draw(sheet)
for i,(p,frame) in enumerate(files):
    im=Image.open(p).convert('RGB');assert im.size==(1080,1920)
    im.thumbnail((260,462));x=(i%4)*270;y=(i//4)*510
    sheet.paste(im,(x,y));draw.text((x+6,y+470),f'{p.stem} | f{frame}',fill='white')
sheet.save(OUT/'storyboard-contact-sheet.jpg',quality=93)
# AAC output loudness and true peak, measured without changing the file.
loud=run(['ffmpeg','-hide_banner','-i',str(VIDEO),'-af','loudnorm=print_format=json','-f','null','-']).stderr
(OUT/'final-audio-loudness.log').write_text(loud)
m=re.search(r'\{\s*"input_i"[\s\S]*?\}',loud)
loudness=json.loads(m.group(0))
assert float(loudness['input_tp'])<0
# Verify that encoded drum onsets still align with the source waveform timing.
pcm=OUT/'verification-audio.wav'
run(['ffmpeg','-v','error','-y','-i',str(VIDEO),'-vn','-ac','1','-ar','48000',str(pcm)])
sr,encoded=wavfile.read(pcm)
sr2,original=wavfile.read(ROOT/'public/assets/audio/the-unbroken-city.wav')
source=original.astype(float).mean(axis=1)
# Cross-correlate +/- 1024 samples on an early window, accommodating AAC padding.
from scipy.signal import correlate,correlation_lags
x=encoded[:sr*3].astype(float);y=source[:sr*3]
c=correlate(x,y,mode='full',method='fft');lags=correlation_lags(len(x),len(y),mode='full');mask=abs(lags)<=1024
lag=int(lags[mask][np.argmax(c[mask])])
assert abs(lag/sr)<1/30
pcm.unlink()
# Check every encoded frame for unintended near-uniform blank output.
raw=subprocess.run(['ffmpeg','-v','error','-i',str(VIDEO),'-an','-vf','scale=64:114','-f','rawvideo','-pix_fmt','gray','-'],capture_output=True,check=True)
small=np.frombuffer(raw.stdout,np.uint8).reshape(-1,114,64)
contrast=small.std(axis=(1,2))
assert not np.any(contrast[:2083]<.4), 'Unexpected blank frame before intentional final fade'
report={'video':{'codec':v['codec_name'],'width':v['width'],'height':v['height'],'fps':v['r_frame_rate'],'decodedFrames':int(v['nb_read_frames']),'durationSeconds':float(v['duration']),'sha256':hashlib.sha256(VIDEO.read_bytes()).hexdigest()},'audio':{'codec':a['codec_name'],'channels':a['channels'],'durationSeconds':float(a['duration']),'integratedLufs':float(loudness['input_i']),'truePeakDbtp':float(loudness['input_tp']),'encodedAudioLagSamples':lag,'encodedAudioLagMilliseconds':lag/sr*1000,'sourceMeasuredBeatCount':audio['beatCount']},'checks':{'fullFileDecode':'passed; no FFmpeg decode errors','contiguousSceneFrames':'passed; 18 scenes, no gaps or overlaps','sceneCutsOnDetectedBeatFrames':'passed','beatFrameRounding':'within half a frame','headlineWidth':'passed using bundled font metrics','representativeFinalEncodeFrames':18,'audioVideoDurationAgreement':'passed within 50ms','audioPeak':'below 0 dBTP','audioAlignment':'cross-correlation within one video frame','unexpectedBlankFrames':'passed; no near-uniform frames before intentional final fade','minimumFrameLumaStdBeforeFade':round(float(contrast[:2083].min()),3)},'headlineWidths':widths,'sceneFrames':[{'scene':p.stem,'frame':f,'file':str(p.relative_to(ROOT))} for p,f in files],'manualInspection':'Review final contact sheet and full-size scene frames; retain findings separately in output/QC-NOTES.md.','limitations':['Historical claims verified against the article supplied by user; cited books were not independently retrieved.','Modern physical coastline used for geographic orientation; no period shoreline or political-boundary reconstruction.','Military illustrations are schematic and not to scale.','Meter and phrase grouping derive from the known original score; detected drum beat times derive from the waveform.','Text-led documentary with instrumental audio, no spoken narration.']}
(OUT/'quality-control.json').write_text(json.dumps(report,indent=2))
print('PASS: 2100 decoded frames, 18 extracted scene frames, valid stereo AAC, beat-aligned timeline.')
print('Audio:',report['audio'])
