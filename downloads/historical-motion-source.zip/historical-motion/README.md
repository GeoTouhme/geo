# The Unbroken City

A 70-second, text-led animated documentary about the second Arab siege of
Constantinople (717–718), made with React, TypeScript, Remotion, SVG and an
original procedural instrumental score. No generative imagery, video models,
stock footage, sampled recordings or voiceover are used.

## Deliverables

- `output/historical_documentary.mp4` — H.264, 1080×1920, 30 FPS, stereo AAC.
- `src/` — editable, deterministic Remotion project.
- `src/data/historicalFacts.json` and `research/article-supplied.txt` — claims and source.
- `STORYBOARD.md` and `src/data/sceneTimeline.json` — 18-scene production timeline.
- `src/data/audioBeats.json` — measured beat times, relative strengths, phrases,
  and assigned visual events.
- `public/assets/audio/the-unbroken-city.wav` — original CC0 instrumental score.
- `output/storyboard-contact-sheet.jpg` — frames extracted from the final video.
- `output/quality-control.json` — automated validation evidence and limitations.
- `CREDITS.md` — sources, licenses, and research limitations.

The source ZIP contains source/assets and quality-control evidence. The final
MP4 is delivered separately to avoid duplicating it in the archive.

## Reproduce the final video

Use the existing checkout/directory; no Git worktree is needed. In the prepared
cloud environment, Node 24, npm 11, FFmpeg 7, Python 3.12 and system Chromium are
available. Local fonts, the score, and prepared geographic geometry are included.
No research network access is needed to render the supplied project.

```sh
cd /workspace/historical-motion
npm ci
npm run typecheck
npm run render
```

Rendering uses `/usr/bin/chromium`, four workers, CRF 17, and 320 kbps stereo AAC.
On another Linux machine, install Chromium and FFmpeg or adapt the executable
path in `package.json`. Rendering on different browser/font-rasterizer versions
may produce small pixel differences. All timing and procedural graphics are
frame-deterministic. npm's cache path is configured in `.npmrc`; change that
non-secret local cache location if `/workspace` is unavailable.

Interactive editing: `npm run studio`. This opens Remotion Studio; select the
`HistoricalDocumentary` composition. `RenderCheck` remains a separate technical
diagnostic and is not the documentary.

## Rebuild the analysis and source assets (optional)

The generated assets are already included. The following commands regenerate
them and require Python numerical dependencies:

```sh
python -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python scripts/compose_score.py
.venv/bin/python scripts/analyze_audio.py
.venv/bin/python scripts/plan_production.py
.venv/bin/python scripts/prepare_maps.py
npm run render
.venv/bin/python scripts/quality_control.py
```

`prepare_maps.py` accepts normal installed Shapely and also the cloud's local
`.python` dependency directory. The full source Natural Earth geometry is bundled
under `research/natural-earth.geojson`, along with its public-domain terms.

`analyze_audio.py` measures 35–90 Hz energy at 5 ms resolution and finds drum
transient leading edges. It does not replace measured times with a tempo grid.
4/4 meter and phrase groupings use the known original composition; those are not
claimed as independent downbeat or section inference. The final sustained chord
is excluded from drum-beat detection. `plan_production.py` assigns scene changes
and headline reveals to measured beat frames. Do not regenerate the beat map
without regenerating the storyboard as well.

## Editorial notes

The article was supplied directly by the user. The claims were checked against
that text. Direct Wikipedia and independent reference retrieval were denied by
the environment's proxy; the bibliography in the supplied article was not
independently read. This limitation is preserved in the structured research.

No troop totals, casualty totals, exact siege-opening day, legendary grain
stories, or unsupported period flags are presented. Bulgar action is dated
only to the siege because the sources differ about its chronology. Military
symbols, routes, city silhouettes and architectural forms are conceptual
illustrations. Military diagrams are labeled schematic and have no quantitative
scale. The map uses a verified **modern physical coastline for orientation**,
not period political boundaries or a reconstructed eighth-century shoreline.
The city marker uses the coordinates in the supplied article.

Music is an original contemporary instrumental accompaniment, not a historical
reconstruction. There is no narration track; the story is communicated through
on-screen titles, brief explanatory captions, and animated graphics.

## Quality control

Run `npm run typecheck`, render the film, then run
`python scripts/quality_control.py`. The script decodes all frames, checks the
container streams and duration, validates contiguous scene timing and beat
alignment, extracts one frame from every scene from the actual MP4, creates a
contact sheet, measures audio loudness and peak levels, and saves its findings.
Visual inspection of the extracted frames is still required; numerical checks
do not independently prove map accuracy or historical truth.

The final half-second intentionally fades into the navy background while the
score resolves. No extra black title leader or silent end card is appended.
