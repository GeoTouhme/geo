# Sources, credits, and licenses

## Historical research

**Wikipedia contributors, “Siege of Constantinople (717–718).”**
https://en.wikipedia.org/wiki/Siege_of_Constantinople_(717%E2%80%93718)

Source text supplied by the user, stored verbatim in
`research/article-supplied.txt`. Its footer reports an edit date of 24 August
2026. The exact Wikipedia revision ID was not independently verified.
Text license: Creative Commons Attribution-ShareAlike 4.0 International:
https://creativecommons.org/licenses/by-sa/4.0/
History and contributor attribution:
https://en.wikipedia.org/w/index.php?title=Siege_of_Constantinople_(717%E2%80%93718)&action=history

The film and research notes paraphrase selected factual passages. The film and
adapted research/storyboard text are distributed under CC BY-SA 4.0 to the
extent copyright applies. This does not imply Wikipedia or its contributors
endorse the project.

The article's cited works include Mango & Scott (1997), Lilie (1976), Treadgold
(1997), and Guilland (1959). These citations are retained as bibliographic leads,
not represented as independently consulted books. Independent online source
retrieval was blocked. See `src/data/historicalFacts.json` for claim locators,
uncertainties and omitted disputed material.

## Geographic data

Natural Earth, 1:10m land polygons; public domain.
Data: https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_10m_land.geojson
Terms: https://www.naturalearthdata.com/about/terms-of-use/
Bundled copy of terms: `research/natural-earth-LICENSE.md`.
Downloaded data is retained for offline reproduction and clipped to the Sea of
Marmara region. The map is physical geographic orientation, not a historical
territorial map. No national flags or modern state boundaries are used.

## Music

**The Unbroken City** — original procedural instrumental score, approximately
112 BPM, D minor, stereo, 70 seconds. Synthesized exclusively from oscillators
and seeded noise by `scripts/compose_score.py`; no third-party recordings,
melodies or sampled music were incorporated. The generated audio is dedicated
to the public domain under CC0 1.0 to the extent any rights apply:
https://creativecommons.org/publicdomain/zero/1.0/

Meter and phrase structure are known from the composition; drum onsets and
strengths are measured from its waveform. This is contemporary documentary
music, not a claim about medieval musical practice.

## Fonts

Noto Serif Display Bold and Noto Sans Bold, bundled from the system's Noto fonts.
SIL Open Font License 1.1; see `public/assets/fonts/LICENSE.txt` for the complete
copyright and licensing notices. Fonts remain under their own license.

## Code and graphics

Original program code and procedural vector illustrations are available under
the MIT license in `LICENSE-CODE.txt`. Geographic data, fonts, source text and
adapted textual content retain the licenses above. Remotion and other software
dependencies retain their own licenses; Remotion's current usage terms may
apply when used commercially. See https://www.remotion.dev/license.
